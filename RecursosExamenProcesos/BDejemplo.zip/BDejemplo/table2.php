<?php
/**
 * Created by PhpStorm.
 * User: migue
 * Date: 25/08/16
 * Time: 16:13
 */

namespace Constantes_DB;


class table2
{
    const TABLE_NAME = "tabla2";
    const NAME = "name";
    const COLUMN_2 = "column_2";

}