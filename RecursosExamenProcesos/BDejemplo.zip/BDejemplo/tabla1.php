<?php
/**
 * Created by PhpStorm.
 * User: migue
 * Date: 25/08/16
 * Time: 16:02
 */

namespace Constantes_DB;
class tabla1
{
    const TABLE_NAME = "tabla1";
    const COD = "cod";
    const NOMBRE = "nombre";
    const EDAD = "edad";
    const LENGUAJE = "lenguaje";

}