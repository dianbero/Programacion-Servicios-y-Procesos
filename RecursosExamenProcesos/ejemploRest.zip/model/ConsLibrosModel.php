<?php


namespace ConstantesDB;

//Class with constants for libros table.
class ConsLibrosModel
{
    const TABLE_NAME = "libros";
    const COD = "codigo";
    const TITULO = "titulo";
    const PAGS = "numpag";
}